﻿//-----------------------------------------------------------------------
// <copyright file="CustomerController.cs" company="Genesys Source">
//      Licensed to the Apache Software Foundation (ASF) under one or more 
//      contributor license agreements.  See the NOTICE file distributed with 
//      this work for additional information regarding copyright ownership.
//      The ASF licenses this file to You under the Apache License, Version 2.0 
//      (the 'License'); you may not use this file except in compliance with 
//      the License.  You may obtain a copy of the License at 
//       
//        http://www.apache.org/licenses/LICENSE-2.0 
//       
//       Unless required by applicable law or agreed to in writing, software  
//       distributed under the License is distributed on an 'AS IS' BASIS, 
//       WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.  
//       See the License for the specific language governing permissions and  
//       limitations under the License. 
// </copyright>
//-----------------------------------------------------------------------
using System;
using System.Web.Mvc;
using Genesys.Extensions;
using Genesys.Extras.Web.Http;
using Framework.Customer;
using Framework.Entity;

namespace Framework.WebServices
{
    /// <summary>
    /// Creates a Customer
    /// </summary>
    [Authorize()]
    public class CustomerController : WebApiController
    {
        public const string ControllerName = "Customer";
        public const string GetAction = "Get";
        public const string PutAction = "Put";
        public const string PostAction = "Post";
        public const string DeleteAction = "Delete";

        /// <summary>
        /// Retrieves entity by key
        /// </summary>
        /// <param name="key">Guid key of the entity to view. Same as int ID, except Guids are near impossible to predict.</param>
        /// <returns>Entity that matches key</returns>
        [HttpGet()]
        public CustomerModel Get(string key)
        {
            // Validate the data via strong typing
            Guid keyStrong = key.TryParseGuid();

            // Pull the desired customer entity with the data access object
            CustomerInfo customer = CustomerInfo.GetByKey(keyStrong);

            // Fill the CustomerModel view model, so the class can be specific to the screen's needs and drop the heavy data access items.
            CustomerModel model = CustomerModel.Fill(customer);

            // Return the view model to the screen
            return model;
        }

        /// <summary>
        /// Creates a new customer
        /// </summary>
        /// <returns></returns>
        [HttpPut()]
        public CustomerModel Put(CustomerModel screenData)
        {
            // Convert the view model to the data access object
            CustomerInfo customer = CustomerInfo.Fill(screenData);

            // Save screen changes to database.
            customer.Save();

            // Fill the CustomerModel view model, so the class can be specific to the screen's needs and drop the heavy data access items.
            CustomerModel model = CustomerModel.Fill(customer);

            // Return the view model to the screen
            return model;
        }

        /// <summary>
        /// Saves changes to a Customer
        /// </summary>
        /// <param name="screenData"></param>
        /// <returns></returns>
        [HttpPost()]
        public CustomerModel Post(CustomerModel screenData)
        {
            // Convert the view model to the data access object
            CustomerInfo customer = CustomerInfo.Fill(screenData);

            // Save screen changes to database.
            customer.Save();

            // Fill the CustomerModel view model, so the class can be specific to the screen's needs and drop the heavy data access items.
            CustomerModel model = CustomerModel.Fill(customer);

            // Return saved customer. An insert will now have a valid ID.
            return model;
        }

        /// <summary>
        /// Saves changes to a Customer
        /// </summary>
        /// <param name="screenData"></param>
        /// <returns></returns>
        [HttpDelete()]
        public CustomerModel Delete(Guid key)
        {
            // Pull the desired customer entity with the data access object
            CustomerInfo customer = CustomerInfo.GetByKey(key);

            // Delete record from database
            customer.Delete();

            // Fill the CustomerModel view model, so the class can be specific to the screen's needs and drop the heavy data access items.
            CustomerModel model = new CustomerModel();

            // Return the now-empty view model to the screen
            return model;
        }        
    }
}