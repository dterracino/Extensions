﻿CREATE SCHEMA [Activity]
    AUTHORIZATION [dbo];

