﻿//-----------------------------------------------------------------------
// <copyright file="CustomerCloudTests.cs" company="Genesys Source">
//      Licensed to the Apache Software Foundation (ASF) under one or more 
//      contributor license agreements.  See the NOTICE file distributed with 
//      this work for additional information regarding copyright ownership.
//      The ASF licenses this file to You under the Apache License, Version 2.0 
//      (the 'License'); you may not use this file except in compliance with 
//      the License.  You may obtain a copy of the License at 
//       
//        http://www.apache.org/licenses/LICENSE-2.0 
//       
//       Unless required by applicable law or agreed to in writing, software  
//       distributed under the License is distributed on an 'AS IS' BASIS, 
//       WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.  
//       See the License for the specific language governing permissions and  
//       limitations under the License. 
// </copyright>
//-----------------------------------------------------------------------
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using System.Collections.Generic;
using System.Linq;
using Genesys.Extensions;
using Framework.Entity;
using Framework.Customer;
using Genesys.Extras.Mathematics;
using Genesys.Extras.Net;
using Genesys.Extras.Configuration;
using System.Threading.Tasks;

namespace Framework.Tests
{
    /// <summary>
    /// Test framework functionality
    /// </summary>
    /// <remarks></remarks>
    [TestClass()]
    public class CustomerCloudTests
    {
        List<int> recycleBin = new List<int>();
        List<CustomerModel> customersFromScreen = new List<CustomerModel>()
        {
            new CustomerModel() {FirstName = "John", MiddleName = "Adam", LastName = "Doe", BirthDate = DateTime.Today.AddYears(Arithmetic.Random(2).Negate()) },
            new CustomerModel() {FirstName = "Jane", MiddleName = "Michelle", LastName = "Smith", BirthDate = DateTime.Today.AddYears(Arithmetic.Random(2).Negate()) },
            new CustomerModel() {FirstName = "Xi", MiddleName = "", LastName = "Ling", BirthDate = DateTime.Today.AddYears(Arithmetic.Random(2).Negate()) },
            new CustomerModel() {FirstName = "Juan", MiddleName = "", LastName = "Gomez", BirthDate = DateTime.Today.AddYears(Arithmetic.Random(2).Negate()) },
            new CustomerModel() {FirstName = "Maki", MiddleName = "", LastName = "Ishii", BirthDate = DateTime.Today.AddYears(Arithmetic.Random(2).Negate()) }
        };

        /// <summary>
        /// Create a new customer in the cloud
        /// </summary>
        /// <remarks></remarks>
        [TestMethod()]
        public async Task Customer_Cloud_CustomerNew()
        {
            CustomerModel newCustomer = new CustomerModel();
            CustomerModel returnCustomer = new CustomerModel();
            int newID = TypeExtension.DefaultInteger;
            Guid newKey = TypeExtension.DefaultGuid;
            string urlRoot = new ConfigurationManagerFull().AppSettingValue("MyWebService");
            string urlFull = String.Format("{0}/{1}", urlRoot, "Customer");
            HttpRequestPut<CustomerModel, CustomerModel> request;

            // Simulate the service layer transforming the Model (CustomerModel) to the Data Access Object (CustomerInfo)
            newCustomer.FillByInterface(customersFromScreen[Arithmetic.Random(1, 5)]);

            // Call the cloud and get results
            request = new HttpRequestPut<CustomerModel, CustomerModel>(urlFull, newCustomer);
            returnCustomer = await request.SendAsync();
            newID = returnCustomer.ID;
            newKey = returnCustomer.Key;

            Assert.IsTrue(newID != TypeExtension.DefaultInteger, "Customer did not save.");
            Assert.IsTrue(newKey != TypeExtension.DefaultGuid, "Customer did not save.");

            // Inserted records must be added to recycle bin for cleanup
            recycleBin.Add(newCustomer.ID);
        }

        /// <summary>
        /// Edit a customer in the cloud
        /// </summary>
        /// <remarks></remarks>
        [TestMethod()]
        public async Task Customer_Cloud_CustomerEdit()
        {
            CustomerModel newCustomer = new CustomerModel();
            CustomerModel returnCustomer = new CustomerModel();
            int newID = TypeExtension.DefaultInteger;
            Guid newKey = TypeExtension.DefaultGuid;
            string urlRoot = new ConfigurationManagerFull().AppSettingValue("MyWebService");
            string urlFull = String.Format("{0}/{1}", urlRoot, "Customer");
            HttpRequestPost<CustomerModel, CustomerModel> request;

            // Simulate the service layer transforming the Model (CustomerModel) to the Data Access Object (CustomerInfo)
            newCustomer.FillByInterface(customersFromScreen[Arithmetic.Random(1, 5)]);

            // Call the cloud and get results
            request = new HttpRequestPost<CustomerModel, CustomerModel>(urlFull, newCustomer);
            returnCustomer = await request.SendAsync();
            newID = returnCustomer.ID;
            newKey = returnCustomer.Key;

            Assert.IsTrue(newID != TypeExtension.DefaultInteger, "Customer did not save.");
            Assert.IsTrue(newKey != TypeExtension.DefaultGuid, "Customer did not save.");

            // Inserted records must be added to recycle bin for cleanup
            recycleBin.Add(newCustomer.ID);
        }

        /// <summary>
        /// Delete a customer from the cloud
        /// </summary>
        /// <remarks></remarks>
        [TestMethod()]
        public async Task Customer_Cloud_CustomerGet()
        {
            CustomerModel returnCustomer = new CustomerModel();
            HttpRequestGet<CustomerModel> request;
            Guid keyToGet = TypeExtension.DefaultGuid;
            string urlRoot = new ConfigurationManagerFull().AppSettingValue("MyWebService");
            string urlFull = TypeExtension.DefaultString;

            // Get an ID from the database, to pass to cloud
            keyToGet = CustomerInfo.GetAll().Take(1).FirstOrDefaultSafe().Key;
            // Call the cloud and get results
            urlFull = String.Format("{0}/{1}/{2}", urlRoot, "Customer", keyToGet);
            request = new HttpRequestGet<CustomerModel>(urlFull);
            returnCustomer = await request.SendAsync();

            Assert.IsTrue(returnCustomer.ID != TypeExtension.DefaultInteger, "Customer did not get.");
            Assert.IsTrue(returnCustomer.Key != TypeExtension.DefaultGuid, "Customer did not get.");
        }

        /// <summary>
        /// Get a customer from the cloud
        /// </summary>
        /// <remarks></remarks>
        [TestMethod()]
        public void Customer_Cloud_CustomerDelete()
        {
            CustomerInfo newCustomer = new CustomerInfo();
            int toDeleteID = TypeExtension.DefaultInteger;

            toDeleteID = recycleBin.Count() > 0 ? recycleBin[0] : CustomerInfo.GetAll().Take(1).FirstOrDefaultSafe().ID;
            newCustomer = CustomerInfo.GetByID(toDeleteID);
            newCustomer.Delete();
            Assert.IsTrue(newCustomer.ID != TypeExtension.DefaultInteger, "Customer didnt delete.");
        }

        /// <summary>
        /// Get customer types
        /// </summary>
        /// <remarks></remarks>
        [TestMethod()]
        public void Customer_Cloud_CustomerTypeGet()
        {
            IQueryable<CustomerType> types = CustomerType.GetAll();
            Assert.IsTrue(types.ToList().Count > 0, "Did not work");
        }

        /// <summary>
        /// Cleanup all data
        /// </summary>
        [ClassCleanupAttribute()]
        private void Cleanup()
        {
            foreach (int item in recycleBin)
            {
                CustomerInfo.GetByID(item).Delete();
            }
        }
    }
}
