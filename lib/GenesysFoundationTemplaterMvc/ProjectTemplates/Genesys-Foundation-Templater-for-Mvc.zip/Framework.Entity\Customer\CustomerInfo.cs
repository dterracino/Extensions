﻿//-----------------------------------------------------------------------
// <copyright file="CustomerInfo.cs" company="Genesys Source">
//      Licensed to the Apache Software Foundation (ASF) under one or more 
//      contributor license agreements.  See the NOTICE file distributed with 
//      this work for additional information regarding copyright ownership.
//      The ASF licenses this file to You under the Apache License, Version 2.0 
//      (the 'License'); you may not use this file except in compliance with 
//      the License.  You may obtain a copy of the License at 
//       
//        http://www.apache.org/licenses/LICENSE-2.0 
//       
//       Unless required by applicable law or agreed to in writing, software  
//       distributed under the License is distributed on an 'AS IS' BASIS, 
//       WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.  
//       See the License for the specific language governing permissions and  
//       limitations under the License. 
// </copyright>
//-----------------------------------------------------------------------
using System;
using Genesys.Extras.Text.Cleansing;
using Genesys.Foundation.Activity;
using Genesys.Foundation.Data;
using Framework.Customer;
using Genesys.Foundation.Entity;
using System.Linq;

namespace Framework.Entity
{
    /// <summary>
    /// EntityCustomer
    /// </summary>
    [CLSCompliant(true), ConnectionString("MyCodeConnection")]
    public partial class CustomerInfo : SaveableEntity<CustomerInfo>, ICustomer
    {
        /// <summary>
        /// Constructor
        /// </summary>
        public CustomerInfo()
            : base()
        {
        }

        /// <summary>
        /// Gets all records that exactly equal passed name
        /// </summary>
        /// <param name="name">Value to search CustomerTypeName field </param>
        /// <returns>All records matching the passed name</returns>
        public static IQueryable<CustomerInfo> GetByNameBirthdayKey(string firstName, string middleName, string lastName, DateTime birthDate)
        {
            DatabaseContext dbContext = new DatabaseContext();
            IQueryable<CustomerInfo> returnValue = dbContext.EntityData
                .Where(x => x.FirstName == firstName && x.MiddleName == middleName && x.LastName == lastName && x.BirthDate == birthDate);
            return returnValue;
        }

        /// <summary>
        /// Save the entity to the database. This method will auto-generate activity tracking.
        /// </summary>
        public override int Save()
        {
            // Ensure data does not contain cross site scripting injection HTML/Js/SQL
            this.FirstName = new HtmlUnsafeCleanser(this.FirstName).Cleanse();
            this.MiddleName = new HtmlUnsafeCleanser(this.MiddleName).Cleanse();
            this.LastName = new HtmlUnsafeCleanser(this.LastName).Cleanse();
            base.Save();
            return this.ID;
        }

        /// <summary>
        /// Save the entity to the database.
        /// This method requires a valid Activity to track this database commit
        /// </summary>
        /// <param name="activity">Activity tracking this record</param>
        public override int Save(IActivity activity)
        {
            // Ensure data does not contain cross site scripting injection HTML/Js/SQL
            this.FirstName = new HtmlUnsafeCleanser(this.FirstName).Cleanse();
            this.MiddleName = new HtmlUnsafeCleanser(this.MiddleName).Cleanse();
            this.LastName = new HtmlUnsafeCleanser(this.LastName).Cleanse();
            base.Save(activity);
            return this.ID;
        }
    }
}
