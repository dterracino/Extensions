﻿CREATE SCHEMA [Customer]
    AUTHORIZATION [dbo];

