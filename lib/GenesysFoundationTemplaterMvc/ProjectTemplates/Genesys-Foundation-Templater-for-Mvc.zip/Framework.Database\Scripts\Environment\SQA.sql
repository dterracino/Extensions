﻿PRINT N'Environment-specific script for TargetEnvironment: $(TargetEnvironment)';
