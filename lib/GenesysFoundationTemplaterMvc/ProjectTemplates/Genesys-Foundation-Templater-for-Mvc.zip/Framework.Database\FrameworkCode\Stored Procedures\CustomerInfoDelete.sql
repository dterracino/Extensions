﻿Create Procedure [FrameworkCode].[CustomerInfoDelete]
	@ID	INT,
	@ActivityID		INT
AS
	Delete
	From	[Customer].[Customer]
	Where	CustomerID = @ID