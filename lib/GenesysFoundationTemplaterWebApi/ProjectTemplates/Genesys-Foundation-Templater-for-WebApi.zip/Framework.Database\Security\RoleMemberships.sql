﻿--ALTER ROLE [db_datareader] ADD MEMBER [YourDomain\WebSiteUser];
--GO
--ALTER ROLE [db_datawriter] ADD MEMBER [YourDomain\WebSiteUser];
--GO
--ALTER ROLE [db_accessadmin] ADD MEMBER [YourDomain\WebSiteUser];
--GO
 
ALTER ROLE [db_datareader] ADD MEMBER [VGO\VGOWebDevUser];
GO
ALTER ROLE [db_datawriter] ADD MEMBER [VGO\VGOWebDevUser];
GO
ALTER ROLE [db_accessadmin] ADD MEMBER [VGO\VGOWebDevUser];
GO
 