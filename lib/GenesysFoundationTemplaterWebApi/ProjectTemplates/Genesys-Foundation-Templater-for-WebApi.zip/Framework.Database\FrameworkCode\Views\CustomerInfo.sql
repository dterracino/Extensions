﻿Create View [FrameworkCode].[CustomerInfo]
As
Select	C.[CustomerID] As [ID],
		C.[CustomerKey] As [Key],
		C.[FirstName], 
		C.[MiddleName], 
		C.[LastName], 
		C.[BirthDate], 
		C.[CustomerTypeID],
		C.[CreatedActivityID] As [ActivityID],
		C.[CreatedDate], 
		C.[ModifiedDate]
From	[Customer].[Customer] C
