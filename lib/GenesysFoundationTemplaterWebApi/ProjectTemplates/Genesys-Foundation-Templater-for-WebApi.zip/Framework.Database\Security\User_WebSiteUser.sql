﻿--CREATE USER [YourDomain\WebSiteUser] FOR LOGIN [YourDomain\WebSiteUser];

CREATE USER [VGO\VGOWebDevUser] FOR LOGIN [VGO\VGOWebDevUser];