﻿//-----------------------------------------------------------------------
// <copyright file="CustomerController.cs" company="Genesys Source">
//      Licensed to the Apache Software Foundation (ASF) under one or more 
//      contributor license agreements.  See the NOTICE file distributed with 
//      this work for additional information regarding copyright ownership.
//      The ASF licenses this file to You under the Apache License, Version 2.0 
//      (the 'License'); you may not use this file except in compliance with 
//      the License.  You may obtain a copy of the License at 
//       
//        http://www.apache.org/licenses/LICENSE-2.0 
//       
//       Unless required by applicable law or agreed to in writing, software  
//       distributed under the License is distributed on an 'AS IS' BASIS, 
//       WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.  
//       See the License for the specific language governing permissions and  
//       limitations under the License. 
// </copyright>
//-----------------------------------------------------------------------
using System;
using System.Web.Mvc;
using Genesys.Extras.Web.Http;
using Framework.Customer;
using Framework.Entity;
using Genesys.Extensions;

namespace Framework.WebApp
{
    /// <summary>
    /// Creates a Customer
    /// </summary>
    public class CustomerController : MvcController
    {
        public const string ControllerName = "Customer";
        public const string SearchAction = "Search";
        public const string SearchView = "~/Views/Customer/CustomerSearch.cshtml";
        public const string SummaryAction = "Summary";
        public const string SummaryView = "~/Views/Customer/CustomerSummary.cshtml";
        public const string CreateAction = "Create";
        public const string CreateView = "~/Views/Customer/CustomerCreate.cshtml";
        public const string EditAction = "Edit";
        public const string EditView = "~/Views/Customer/CustomerEdit.cshtml";
        public const string DeleteAction = "Delete";
        public const string DeleteView = "~/Views/Customer/CustomerDelete.cshtml";

        /// <summary>
        /// Searches entity
        /// </summary>
        /// <returns>View rendered with model data</returns>
        [HttpGet()]
        public ActionResult Search()
        {
            // Return the view model to the screen
            return View(CustomerController.SearchView);
        }

        /// <summary>
        /// Performs the entity search
        /// </summary>
        /// <returns>View rendered with model data</returns>
        [HttpPost()]
        public ActionResult Search(Guid screenData)
        {
            CustomerInfo customer = new CustomerInfo();
            CustomerModel model = new CustomerModel();
            ActionResult returnValue = View(CustomerController.SearchView);

            // Pull the desired customer entity with the data access object
            customer = CustomerInfo.GetByKey(screenData);
            // Success? Show summary
            if (customer.Key != TypeExtension.DefaultGuid)
            {
                // Fill the CustomerModel view model, so the class can be specific to the screen's needs and drop the heavy data access items.
                model = CustomerModel.Fill(customer);
                returnValue = View(CustomerController.SummaryView, model);
            }

            // Return the view model to the screen
            return returnValue;
        }

        /// <summary>
        /// Displays entity
        /// </summary>
        /// <returns>View rendered with model data</returns>
        [HttpGet()]
        public ActionResult Summary()
        {
            // Pull the desired customer entity with the data access object
            CustomerInfo customer = CustomerInfo.GetAll().FirstOrDefaultSafe();

            // Fill the CustomerModel view model, so the class can be specific to the screen's needs and drop the heavy data access items.
            CustomerModel model = CustomerModel.Fill(customer);

            // Return the view model to the screen
            return View(CustomerController.SummaryView, model);
        }

        /// <summary>
        /// Displays entity for editing
        /// </summary>
        /// <returns>View rendered with model data</returns>
        [HttpGet()]
        public ActionResult Create()
        {
            // Pull the desired customer entity with the data access object
            CustomerInfo customer = CustomerInfo.GetAll().FirstOrDefaultSafe();

            // Fill the CustomerModel view model, so the class can be specific to the screen's needs and drop the heavy data access items.
            CustomerModel model = CustomerModel.Fill(customer);

            // Return the view model to the screen
            return View(CustomerController.CreateView, model);
        }

        /// <summary>
        /// Saves changes to a Customer
        /// </summary>
        /// <param name="screenData">Full customer model worth of data to be saved</param>
        /// <returns>View rendered with model data</returns>
        [HttpPost()]
        public ActionResult Create(CustomerModel screenData)
        {
            // Convert the view model to the data access object
            CustomerInfo customer = CustomerInfo.Fill(screenData);

            // Save screen changes to database.
            customer.Save();

            // Return saved customer. An insert will now have a valid ID.
            return View(CustomerController.CreateView, customer);
        }

        /// <summary>
        /// Displays entity for editing
        /// </summary>
        /// <returns>View rendered with model data</returns>
        [HttpGet()]
        public ActionResult Edit()
        {
            // Pull the desired customer entity with the data access object
            CustomerInfo customer = CustomerInfo.GetAll().FirstOrDefaultSafe();

            // Fill the CustomerModel view model, so the class can be specific to the screen's needs and drop the heavy data access items.
            CustomerModel model = CustomerModel.Fill(customer);

            // Return the view model to the screen
            return View(CustomerController.EditView, model);
        }

        /// <summary>
        /// Saves changes to a Customer
        /// </summary>
        /// <param name="screenData">Full customer model worth of data with user changes</param>
        /// <returns>View rendered with model data</returns>
        [HttpPost()]
        public ActionResult Edit(CustomerModel screenData)
        {
            // Convert the view model to the data access object
            CustomerInfo customer = CustomerInfo.Fill(screenData);

            // Save screen changes to database.
            customer.Save();

            // Return saved customer.
            return View(CustomerController.EditView, customer);
        }

        /// <summary>
        /// Displays entity for deleting
        /// </summary>
        /// <returns>View rendered with model data</returns>
        [HttpGet()]
        public ActionResult Delete()
        {
            // Pull the desired customer entity with the data access object
            CustomerInfo customer = CustomerInfo.GetAll().FirstOrDefaultSafe();

            // Fill the CustomerModel view model, so the class can be specific to the screen's needs and drop the heavy data access items.
            CustomerModel model = CustomerModel.Fill(customer);

            // Return the view model to the screen
            return View(CustomerController.DeleteView, model);
        }

        /// <summary>
        /// Deletes a customer by key
        /// </summary>
        /// <param name="screenData">Customer.Key to delete</param>
        /// <returns>View rendered with model data</returns>
        [HttpPost()]
        public ActionResult Delete(Guid screenData)
        {
            // Get entity by passed key (ID equivalent)
            CustomerInfo customer = CustomerInfo.GetByKey(screenData);

            // Save screen changes to database.
            customer.Delete();

            // Return saved customer.
            return View(CustomerController.DeleteView, customer);
        }
    }
}