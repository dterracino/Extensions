﻿CREATE SCHEMA [FrameworkCode]
    AUTHORIZATION [dbo];

