﻿Create Procedure [EntityCode].[CustomerInfoUpdate]
	@ID				int,
	@FirstName		nvarchar(50),
	@MiddleName		nvarchar(50),
	@LastName		nvarchar(50),
	@BirthDate		datetime,
	@CustomerTypeID int,
	@ActivityID		int
AS
	-- Local variables
	Declare @Key As Uniqueidentifier
	-- Initialize
	Select 	@FirstName		= RTRIM(LTRIM(@FirstName))
	Select 	@MiddleName		= RTRIM(LTRIM(@MiddleName))
	Select 	@LastName		= RTRIM(LTRIM(@LastName))
	
	-- Only update with good data
	Select  @CustomerTypeID = CustomerTypeID From [Entity].[CustomerType] Where CustomerTypeID = @CustomerTypeID
	If ((@FirstName <> '') Or (@MiddleName <> '') Or (@LastName <> '')) And (@ActivityID <> -1) And (@CustomertypeID Is Not Null)
	Begin
		-- Find existing to insert vs. update
		Select @ID = C.[CustomerID] From [Entity].[Customer] C Where C.[CustomerID] = @ID
		-- Insert vs Update
		Begin Try
			If (@ID Is Null) Or (@ID = -1)
			Begin
				-- This was an insert passed to the update. Create Customer record
				Select @Key = NewID()
				Insert Into [Entity].[Customer] (CustomerKey, FirstName, MiddleName, LastName, BirthDate, CustomerTypeID, CreatedActivityID, ModifiedActivityID)
					Values (@Key, @FirstName, @MiddleName, @LastName, @BirthDate, @CustomerTypeID, @ActivityID, @ActivityID)	
				Select	@ID = SCOPE_IDENTITY()
			End
			Else
			Begin
				-- Create main entity record
				Update P
				Set P.FirstName				= @FirstName, 
					P.MiddleName			= @MiddleName, 
					P.LastName				= @LastName, 
					P.BirthDate				= @BirthDate, 
					P.CustomerTypeID		= @CustomerTypeID,
					P.ModifiedActivityID	= @ActivityID,
					P.ModifiedDate			= GetUTCDate()
				From	[Entity].[Customer] P
				Where	P.CustomerID = @ID
			End
		End Try
		Begin Catch
			Exec [Activity].[ExceptionLogInsert] @ActivityID
		End Catch
	End	

	-- Return data
	Select	IsNull(@ID, -1) As ID
